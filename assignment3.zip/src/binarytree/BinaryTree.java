package binarytree;

import java.util.*;
import java.util.function.Function;

public class BinaryTree<T> {

    private BTNode<T> root;

    public BinaryTree(BTNode<T> root) {
        this.root = root;
    }

    public BTNode<T> getRoot() {
        return root;
    }

    public int size() {
        return root.size();
    }

    public int height() {
        return root.height();
    }

    public void printInOrder() {
        root.printInOrder();
    }

    public void printPreOrder() {
        root.printPreOrder();
    }

    public void printPostOrder() {
        root.printPostOrder();
    }

    /**** Assignment 3 */

    public int numberOfLeaves() {
        if (root == null)
            return 0;
        int leaves = 0;
        Deque<BTNode<T>> stack = new ArrayDeque<>();
        stack.push(root);
        while (!stack.isEmpty()) {
            BTNode<T> n = stack.pop();
            if (n.isLeaf()) {
                leaves++;
            } else {
                BTNode<T> r = n.getRightChild();
                BTNode<T> l = n.getLeftChild();
                if (r != null)
                    stack.push(r);
                if (l != null)
                    stack.push(l);
            }
        }
        return leaves;
    }

    @Override
    public boolean equals(Object other) {
        if (this == other)
            return true;
        if (!(other instanceof BinaryTree))
            return false;

        BinaryTree o = (BinaryTree) other; // raw type cast

        BTNode<T> a = this.root;
        BTNode b = o.getRoot();

        if (a == null || b == null)
            return a == b;

        Deque<BTNode<T>> sa = new ArrayDeque<>();
        Deque<BTNode> sb = new ArrayDeque<>();
        sa.push(a);
        sb.push(b);

        while (!sa.isEmpty() && !sb.isEmpty()) {
            BTNode<T> na = sa.pop();
            BTNode nb = sb.pop();

            if (!Objects.equals(na.getData(), nb.getData()))
                return false;

            BTNode<T> al = na.getLeftChild();
            BTNode<T> ar = na.getRightChild();
            BTNode bl = nb.getLeftChild();
            BTNode br = nb.getRightChild();

            if ((al == null) != (bl == null))
                return false;
            if ((ar == null) != (br == null))
                return false;

            if (ar != null) {
                sa.push(ar);
                sb.push(br);
            }
            if (al != null) {
                sa.push(al);
                sb.push(bl);
            }
        }
        return sa.isEmpty() && sb.isEmpty();
    }

    public int countDepthK(int k) {
        if (k < 0)
            throw new IllegalArgumentException("k must be >= 0");
        if (root == null)
            return 0;
        if (k == 0)
            return 1;

        Deque<BTNode<T>> q = new ArrayDeque<>();
        q.add(root);
        int depth = 0;

        while (!q.isEmpty() && depth < k) {
            int sz = q.size();
            for (int i = 0; i < sz; i++) {
                BTNode<T> n = q.remove();
                BTNode<T> l = n.getLeftChild();
                BTNode<T> r = n.getRightChild();
                if (l != null)
                    q.add(l);
                if (r != null)
                    q.add(r);
            }
            depth++;
        }
        return depth == k ? q.size() : 0;
    }

    public Iterator<T> preOrderIterator() {
        return new PreOrderIterator<>(this);
    }

    static final class PreOrderIterator<T> implements Iterator<T> {
        private final BinaryTree<T> tree;
        private final Deque<BTNode<T>> stack = new ArrayDeque<>();

        PreOrderIterator(BinaryTree<T> tree) {
            this.tree = tree;
            if (tree.getRoot() != null) {
                stack.push(tree.getRoot());
            }
        }

        @Override
        public boolean hasNext() {
            return !stack.isEmpty();
        }

        @Override
        public T next() {
            if (!hasNext())
                throw new NoSuchElementException();
            BTNode<T> n = stack.pop();
            BTNode<T> right = n.getRightChild();
            BTNode<T> left = n.getLeftChild();
            if (right != null)
                stack.push(right);
            if (left != null)
                stack.push(left);
            return n.getData();
        }

        @Override
        public void remove() {
            System.out.println("Remove operation not supported");
        }
    }
}
