package sorting;

import java.util.Arrays;
import java.util.Comparator;

public class MySortingAlgs {

    public static void sortStrings(String[] a) {
        // TODO implement me
        Arrays.sort(a, new Comparator<String>() {
            public int compare(String s1, String s2) {
                int c = Integer.compare(s1.length(), s2.length());
                if (c != 0)
                    return c;
                return s1.compareTo(s2);
            }
        });
    }

    /**
     * Assumption arr[start...mid-1] is sorted and arr[mid...end] is sorted.
     * The function merges the two parts into a sorted subarray arr[start...end]
     * All elements outside arr[start...end] remain unchanged
     */
    public static <T extends Comparable<T>> void merge(T[] arr, int start, int mid, int end) {
        // TODO implement me
        int n = end - start + 1;
        @SuppressWarnings("unchecked")
        T[] tmp = (T[]) new Comparable[n];
        int i = start;
        int j = mid;
        int k = 0;
        while (i <= mid - 1 && j <= end) {
            if (arr[i].compareTo(arr[j]) <= 0) {
                tmp[k++] = arr[i++];
            } else {
                tmp[k++] = arr[j++];
            }
        }
        while (i <= mid - 1) {
            tmp[k++] = arr[i++];
        }
        while (j <= end) {
            tmp[k++] = arr[j++];
        }
        for (int t = 0; t < n; t++) {
            arr[start + t] = tmp[t];
        }
    }

    /**
     * sorts the subarray arr[start...end] using the Merge Sort algorithm
     */
    public static <T extends Comparable<T>> void mergeSort(T[] arr, int start, int end) {
        if (start == end)
            return;

        int mid = (start + end) / 2;
        mergeSort(arr, start, mid - 1);
        mergeSort(arr, mid, end);
        merge(arr, start, mid, end);
    }

    /**
     * sorts the subarray arr using the Merge Sort algorithm
     */
    public static <T extends Comparable<T>> void mergeSort(T[] arr) {
        mergeSort(arr, 0, arr.length - 1);
    }

}
